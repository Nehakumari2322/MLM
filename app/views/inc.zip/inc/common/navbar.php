<form action="<?php echo URLROOT ;?>commons/navbar" method="post" style="margin-bottom:0">
<nav class="navbar navbar-expand-lg " style="background:#ffe55b" >
  <div class="container-fluid">
    <a class="navbar-brand "  href="#">PerfectDream</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        <li class="nav-item">
          <button class="nav-link" type="submit" aria-current="page" name="home" id="home" href="#" style="border:none;background:none;">Home</button>
        </li> 
        
       <?php $selfMember = $_SESSION['selfMember'];
        if($selfMember == null){?>
      
       <?php }
       else{?>
        <li class="nav-item">
          <button class="nav-link" type="submit" aria-current="page" name="dashboard" id="dashboard" href="#" style="border:none;background:none;">Dashboard</button>
        </li>
        <?php }?>
      </ul>
      
    </div>
  </div>
</nav>
</form>