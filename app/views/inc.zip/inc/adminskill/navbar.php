<form action="<?php echo URLROOT ;?>skilladmins/adminnavbar" method="post" >
<nav class="navbar navbar-expand-lg"  style="background:#ffe55b">
      <div class="container-fluid">
        <button class="navbar-brand btn" href="#" name="logo" id="logo">PerfectDream</button>
        <button
          class="navbar-toggler"
          type="button"
          data-bs-toggle="collapse"
          data-bs-target="#navbarNav"
          aria-controls="navbarNav"
          aria-expanded="false"
          aria-label="Toggle navigation"
        >
          <span class="navbar-toggler-icon bg-light"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
          <ul class="navbar-nav">
            <li class="nav-item">
              <button class="nav-link active btn text-dark" aria-current="page" href="#" name="home" id="home">Home</button>
            </li>
            <li class="nav-item">
              <button class="nav-link btn text-dark" aria-current="page" href="#" name="dashboard" id="dashboard">Add Trainer</button>
            </li>
            <li class="nav-item">
              <button class="nav-link btn text-dark" aria-current="page" href="#" name="seeStudent" id="seeStudent">All Student</button>
            </li>
           
         
          </ul>
        </div>
      </div>
    </nav>
</form>