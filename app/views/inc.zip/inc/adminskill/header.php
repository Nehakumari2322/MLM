<!DOCTYPE html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />

    <!-- Bootstrap CSS -->
    <link
      href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css"
      rel="stylesheet"
      integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC"
      crossorigin="anonymous"
    />

    <title>Perfect Dream</title>

    <style>
      body {
        font-family: "Times New Roman", Times, serif;
      }
      .center {
        height: 100%;
        display: flex;
        align-items: center;
        justify-content: center;
        border-radius: 50px;
      }
      .form-input {
        width: 350px;
        padding: 20px;
        background: #fff;
        box-shadow: -3px -3px 7px rgba(94, 104, 121, 0.377),
          3px 3px 7px rgba(94, 104, 121, 0.377);

        border: none;
      }
      .form-input img {
        width: 100%;
        display: none;
        margin-bottom: 30px;
      }
      .form-input input {
        display: none;
      }

      .form-input label {
        display: block;
        width: 45%;
        height: 45px;
        margin-left: 25%;
        line-height: 50px;
        text-align: center;
        background: #1172c2;
        color: #fff;
        font-size: 15px;
        font-family: "Open Sans", sans-serif;
        text-transform: Uppercase;
        font-weight: 600;
        border-radius: 5px;
        cursor: pointer;
      }

      .ui {
        border: none;
      }
    </style>
  </head>
  <body>