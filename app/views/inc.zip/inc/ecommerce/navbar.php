

<form action="<?php echo URLROOT ;?>ecommerceendusers/navformEnd" method="post" style="margin-bottom:0">
<nav class="navbar navbar-expand-lg "  style="background:#ffe55b">
			<div class="container-fluid">
			  <button class="navbar-brand " type="submit" href="#" name="logo" id="logo" style="border:none;background:none">PerfectDream</button>
			  <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
				<span class="navbar-toggler-icon"></span>
			  </button>
			  <div class="collapse navbar-collapse" id="navbarSupportedContent">
				<ul class="navbar-nav  mb-2 mb-lg-0 mx-auto" >
				  <li class="nav-item" >
					<button  class="nav-link " href="#" type="submit" id="Home" name="Home" style="border:none;background:none" >
						<img src="<?php echo URLROOT.'/img/ecommerce/home.png'?>" height="25px" alt="">
					</button>
					
				  </li>
				  <div class="dropdown">
					<a  class="nav-link " aria-current="page" href="#" role="button" id="dropdownMenuLink" data-bs-toggle="dropdown" aria-expanded="false">
					  Fashion
					</a>
					<ul class="dropdown-menu" aria-labelledby="dropdownMenuLink">
					  <li><button class="dropdown-item" href="#" name="men" id="men">Men's</button></li>
					  <li><button class="dropdown-item" href="#" name="women" id="women">Women's</button></li>
					  <li><button class="dropdown-item" href="#" name="kid" id="kid">Kids</button></li>
					</ul>
				  </div>
				  <div class="dropdown">
					<button class="nav-link " aria-current="page" href="#" name="electronic" id="electronic" style="background:none;border:none">Electronics</button>
				  </div>
				  <div class="dropdown">
					<button class="nav-link  " aria-current="page" href="#" name="acces" id="acces" style="background:none;border:none">Accessories</button>
				  </div>
				  <div class="dropdown">
					<button class="nav-link  " aria-current="page" href="#" name="beauty" id="beauty" style="background:none;border:none">Beauty</button>
				  </div>
				  <div class="dropdown">
					<button class="nav-link " aria-current="page" href="#" name="home" id="home" style="background:none;border:none">Home & Kitchen</button>
				  </div>
				  <div class="dropdown">
					<button class="nav-link " aria-current="page" href="#" name="jewellery" id="jewellery" style="background:none;border:none">Jewellery</button>
				  </div>
				  <div class="dropdown">
					<button class="nav-link " aria-current="page" href="#" name="Book" id="Book" style="background:none;border:none">Books</button>
				  </div>
				  <div class="dropdown">
					<button class="nav-link " aria-current="page" href="#" name="bag" id="bag" style="background:none;border:none">Bag & Luggage</button>
				  </div>
				  <div class="dropdown">
					<button class="nav-link" aria-current="page" href="#" name="baby" id="baby" style="background:none;border:none">Baby</button>
				  </div>
				  <div class="dropdown">
					<button class="nav-link" aria-current="page" href="#" name="grossery" id="grossery" style="background:none;border:none">grocery</button>
				  </div>
				  <div class="dropdown">
					<button class="nav-link" aria-current="page" href="#" name="car" id="car" style="background:none;border:none">Motorcycle accessories</button>
				  </div>
				</ul>
				<ul class="ms-auto">
				<button class="btn btn-outline-success" name="cart" id="cart">cart <img src="<?php echo URLROOT.'/img/ecommerce/cart.png'?>" height="20px" width="40px" alt=""></button>
				</ul>
				
	
				
			  </div>
			</div>
		  </nav>
</form>