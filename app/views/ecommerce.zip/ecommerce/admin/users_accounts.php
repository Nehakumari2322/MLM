<?php require APPROOT . '/views/inc/adminecommerce/header.php';?>
<?php require APPROOT . '/views/inc/adminecommerce/navbar.php';?>

<div>
  <center> <h1 class="mt-4 mb-4">USER ACCOUNTS</h1></center>
</div>

<div class="container">
    <div class="row">
        <div class="col-sm-4">
            <div class="card" style="padding:20px; border:2px solid white;box-shadow: 0px 4px 20px rgba(5,57,94,.5);">
                <p style="text-align:center;font-size:1.5rem">Username: &nbsp; <span style="color:red;">Neha Kumari</span></p>
                <p style="text-align:center;font-size:1.4rem">Email :&nbsp;<span style="color:red;"> nehakumarigupta2322@gmail.com<span></p>
                <button class="btn bg-danger" style="color:white;">Delete</button>
            </div>
        </div>
        <div class="col-sm-4">
            <div class="card" style="padding:20px; border:2px solid white;box-shadow: 0px 4px 20px rgba(5,57,94,.5);">
                <p style="text-align:center;color:red;font-size:1.5rem">You have no Message</p>
            </div>
        </div>
        <div class="col-sm-4">
            <div class="card" style="padding:20px; border:2px solid white;box-shadow: 0px 4px 20px rgba(5,57,94,.5);">
                <p style="text-align:center;color:red;font-size:1.5rem">You have no Message</p>
            </div>
        </div>
    </div>
</div>















