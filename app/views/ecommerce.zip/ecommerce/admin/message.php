<?php require APPROOT . '/views/inc/adminecommerce/header.php';?>
<?php require APPROOT . '/views/inc/adminecommerce/navbar.php';?>

<div>
  <center> <h1 class="mt-4 mb-4">Message</h1></center>
</div>

<div class="container">
    <div class="row">
        <div class="col">
            <div class="card" style="margin-left:20%;margin-right:20%;padding:20px; border:2px solid white;box-shadow: 0px 4px 20px rgba(5,57,94,.5);">
                <p style="text-align:center;color:red;font-size:1.5rem">You have no Message</p>
            </div>
        </div>
    </div>
</div>