<?php require APPROOT . '/views/inc/adminecommerce/header.php';?>

<div class="container">
    <iframe src="<?php echo URLROOT.'/product.xlsx';?>" width="100%" height="650px"  frameborder="0"></iframe>
</div>
</body>
</html>