<?php require APPROOT . '/views/inc/ecommerce/header.php';?>
<?php require APPROOT . '/views/inc/ecommerce/navbar.php';?>
<style>
@import url('https://fonts.googleapis.com/css2?family=PT+Serif:ital,wght@1,700&display=swap');

</style>

<div class="container" style="font-family: 'PT Serif', serif; text-align: center;">
<img src="<?php echo URLROOT.'/img/ecommerce/firework-7791_512.gif';?>" class="img-fluid" alt="">
<div class="centered" style="  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);"><h1>Order received successfully !!!!</h1>
<h4>You will receive your products within few days...</h4></div>
</div>